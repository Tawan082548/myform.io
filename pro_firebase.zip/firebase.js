import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBnvWH-_TpJmJ23e-PIKyKFmyIlNWEhOBc",
  authDomain: "fir-rmuti-86c23.firebaseapp.com",
  projectId: "fir-rmuti-86c23",
  storageBucket: "fir-rmuti-86c23.firebasestorage.app",
  messagingSenderId: "422230695877",
  appId: "1:422230695877:web:67ba59ccf148d5463f35ac"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

async function saveFormData(formId, collectionName) {
  const form = document.getElementById(formId);
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    let data = {};
    [...form.elements].forEach(el => {
      if (el.name) data[el.name] = el.value;
    });
    try {
      await addDoc(collection(db, collectionName), {
        ...data,
        createdAt: new Date()
      });
      alert("บันทึกข้อมูลสำเร็จ!");
      form.reset();
    } catch (err) {
      console.error("Error:", err);
      alert("เกิดข้อผิดพลาด!");
    }
  });
}

saveFormData("registerForm", "users");
saveFormData("loginForm", "logins");
saveFormData("studentForm", "students");
saveFormData("adminForm", "admins");
saveFormData("historyForm", "history");
saveFormData("printForm", "prints");
